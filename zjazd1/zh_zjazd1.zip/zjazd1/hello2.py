a = 'Hello world.'
b = '  Ala ma już Kota.'
c= a + b
print(c)

#print("Ala\'s ma już Kota.")

print("Ala\'s ma już\tKota.")
print('jedna linia\ndruga linia')
print('Kot ',end='')
print(' Ela',end='')
print(' Ada',end='')

# domyślnie wartościa partametru end jest '\n'

print('Ada',end='\n')
print('Koniec')
print('Ala', 'Ola', 'Ela', sep=';', end='*\n')
print('Koniec')