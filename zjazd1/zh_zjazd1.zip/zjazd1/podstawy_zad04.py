print('Wpisz cenę za kilogram:')
cena_kg = float(input())
print('Wpisz wagę:')
waga = float(input())
kwota = cena_kg*waga
print(f'Należność  {kwota}')
#inaczej
cena1= float(input('cenę za kilogram:'))
waga1= float(input('waga:'))
koszt1= cena1*waga1
print(f'Należność  {koszt1}')