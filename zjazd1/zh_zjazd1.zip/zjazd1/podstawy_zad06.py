print('podal liczbę A:')
A = int(input('liczba A:'))
warunek1 = A>10
print(f'większa od 10:{warunek1}')
D = A<=15
print(f'mniejsza od 15:{D}')
E = A%2==0
print(f'podzielna przez 2:{E}')