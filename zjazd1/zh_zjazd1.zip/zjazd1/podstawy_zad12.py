skarbonka=20
while skarbonka < 100:
    wplata = int(input('podaj kwotę:'))
    skarbonka += wplata
    print(f'aktualna wartość{skarbonka}')